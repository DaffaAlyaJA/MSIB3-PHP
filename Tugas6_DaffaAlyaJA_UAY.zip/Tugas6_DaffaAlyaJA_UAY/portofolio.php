<?php 
require_once "header.php";
require_once "navbar.php";

?>

<div id="home" class="intro route bg-image" style="background-image: url(assets/img/Mondstadt-Night.jpg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4">Portofolio</h1>
          <p class="intro-subtitle"><span class="text-slider-items">Web Developer,Web Designer,Frontend Developer,Graphic Designer</span><strong class="text-slider"></strong></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div><!-- End Intro Section -->

<!-- ======= Portfolio Section ======= -->
<section id="work" class="portfolio-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Portfolio Project
            </h3>
            <p class="subtitle-a">
              Kumpulan Portofolio saat mengikuti kegiatan MSIB 3 NF Computer.
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/HTML_1.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/HTML_1.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">HTML</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">05 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/HTML_2.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/HTML_2.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">HTML</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">05 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/HTML_3.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/HTML_3.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">HTML</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">05 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/JS_1.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/JS_1.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">JavaScript</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">4 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/JS_2.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/JS_2.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">JavaScript</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">4 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/JS_3.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/JS_3.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">JavaScript</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">4 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/PHP_1.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/PHP_1.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">PHP</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">3 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/PHP_2.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/PHP_2.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">PHP</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">3 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="work-box">
            <a href="assets/img/PHP_3.png" data-gall="portfolioGallery" class="venobox">
              <div class="work-img">
                <img src="assets/img/PHP_3.png" alt="" class="img-fluid">
              </div>
            </a>
            <div class="work-content">
              <div class="row">
                <div class="col-sm-8">
                  <h2 class="w-title">PHP</h2>
                  <div class="w-more">
                    <span class="w-ctegory">Web Design</span> / <span class="w-date">3 Oct. 2022</span>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="w-like">
                    <a href="portfolio-details.html"> <span class="ion-ios-plus-outline"></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
  <!-- End Portfolio Section -->

<?php 
require_once "footer.php";
?>