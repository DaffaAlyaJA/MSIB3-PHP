<?php 
require_once "header.php";
require_once "navbar.php";

?>

<div id="home" class="intro route bg-image" style="background-image: url(assets/img/Mondstadt-Night.jpg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4">Study</h1>
          <p class="intro-subtitle"><span class="text-slider-items">Web Developer,Web Designer,Frontend Developer,Graphic Designer</span><strong class="text-slider"></strong></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div><!-- End Intro Section -->

<!-- ======= Services Section ======= -->
<section id="service" class="services-mf pt-5 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Study
            </h3>
            <p class="subtitle-a">
              Cerita tentang perjalanan dalam menuntut ilmu :
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-monitor"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">TK</h2>
              <p class="s-description text-center">
                TK Pembina<br>
                2006-2007
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-code-working"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Sekolah Dasar</h2>
              <p class="s-description text-center">
                SD Negeri Angsau 4<br>
                2007 - 2013
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-camera"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Sekolah Menengah Pertama</h2>
              <p class="s-description text-center">
                SMP Negeri 2 Pelaihari<br>
                2013 - 2016
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-android-phone-portrait"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Sekolah Menengah Atas</h2>
              <p class="s-description text-center">
                SMA Negeri 1 Pelaihari<br>
                2016 - 2019
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-paintbrush"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Perguruan Tinggi</h2>
              <p class="s-description text-center">
                Universitas Amikom Yogyakarta<br>
                Teknik Komputer<br>
                2019 - ?
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-stats-bars"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Setelah Lulus S1</h2>
              <p class="s-description text-center">
                Apakah saya akan lanjut bersekolah S2 dan seterusnya?
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<!-- End Services Section -->

<?php 
require_once "footer.php";
?>