<?php 
require_once "header.php";
require_once "navbar.php";

?>

<div id="home" class="intro route bg-image" style="background-image: url(assets/img/Mondstadt-Night.jpg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4">Task</h1>
          <p class="intro-subtitle"><span class="text-slider-items">Web Developer,Web Designer,Frontend Developer,Graphic Designer</span><strong class="text-slider"></strong></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div><!-- End Intro Section -->

<!-- ======= Blog Section ======= -->
<section id="blog" class="blog-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Task
            </h3>
            <p class="subtitle-a">
              Kumpulan Tugas-tugas selama mengikuti MSIB Batch 3 di NF Computer.
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="assets/img/HTML_Bg.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Web Design</h6>
                </div>
              </div>
              <h3 class="card-title">HTML</a></h3>
              <p class="card-description">
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/msib3project/blob/main/tugas1_daffaAlyaJalaludinAmin_rezaMaulana_universitasAmikomYogyakarta.html">Tugas 1 HTML</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/msib3project/blob/main/tugas2_daffaAlyaJalaludinAmin_universitasAmikomYogyakarta.html">Tugas 2 HTML</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/msib3project/blob/main/tugas3a_daffaAlyaJalaludinAmin_universitasAmikomYogyakarta_rezaMaulana.html">Tugas 3a HTML</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/msib3project/blob/main/tugas3b_daffaAlyaJalaludinAmin_universitasAmikomYogyakarta_rezaMaulana.html">Tugas 3b HTML</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/msib3project/blob/main/tugas4_daffaAlyaJalaludinAmin_universitasAmikomYogyakarta_rezaMaulana.zip">Tugas 4 HTML</a>
            </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="assets/img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Daffa Alya Jalaludin Amin</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 30 min
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="assets/img/JS_Bg.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Web Design</h6>
                </div>
              </div>
              <h3 class="card-title">JAVASCRIPT</a></h3>
              <p class="card-description">
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-JavaScript/tree/Tugas-1">Tugas 1 JavaScript</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-JavaScript/tree/Tugas-2">Tugas 2 JavaScript</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-JavaScript/tree/Tugas-3">Tugas 3 JavaScript</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-JavaScript/tree/Tugas-4">Tugas 4 JavaScript</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-JavaScript/tree/Tugas-5">Tugas 5 JavaScript</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-JavaScript/tree/Tugas-6">Tugas 6 JavaScript</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-JavaScript/tree/Tugas-7">Tugas 7 JavaScript</a>

              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="assets/img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Daffa Alya Jalaludin Amin</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 10 min
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="assets/img/PHP_Bg.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Web Design</h6>
                </div>
              </div>
              <h3 class="card-title">PHP</a></h3>
              <p class="card-description">
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-PHP/tree/Tugas-2-Php">Tugas 2 Php</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-PHP/tree/Tugas-3-Php">Tugas 3 Php</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-PHP/tree/Tugas-4-Php">Tugas 4 Php</a>
                <li><a target="_blank" href="https://github.com/DaffaAlyaJA/MSIB3-PHP/tree/Tugas-5-Php">Tugas 5 Php</a>

              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="assets/img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Daffa Alya Jalaludin Amin</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 20 min
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Blog Section -->

<?php 
require_once "footer.php";
?>