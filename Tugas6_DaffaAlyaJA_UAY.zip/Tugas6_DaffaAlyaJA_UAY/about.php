<?php 
require_once "header.php";
require_once "navbar.php";

?>

<div id="home" class="intro route bg-image" style="background-image: url(assets/img/Mondstadt-Night.jpg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4">About</h1>
          <p class="intro-subtitle"><span class="text-slider-items">Web Developer,Web Designer,Frontend Developer,Graphic Designer</span><strong class="text-slider"></strong></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div><!-- End Intro Section -->

<!-- ======= About Section ======= -->
<section id="about" class="about-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="box-shadow-full">
            <div class="row">
              <div class="col-md-6">
                <div class="row">
                  <div class="col-sm-6 col-md-5">
                    <div class="about-img">
                      <img src="assets/img/testimonial-2.jpg" class="img-fluid rounded b-shadow-a" alt="">
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-7">
                    <div class="about-info">
                      <p><span class="title-s">Name: </span> <span>Daffa Alya Jalaludin Amin</span></p>
                      <p><span class="title-s">Profile: </span> <span>FullStack Web Developer</span></p>
                      <p><span class="title-s">Email: </span> <span>daffa.0453@students.amikom.ac.id</span></p>
                      <p><span class="title-s">Phone: </span> <span>(+62) 853-4608-6937</span></p>
                    </div>
                  </div>
                </div>
                <div class="skill-mf">
                  <p class="title-s">Skill</p>
                  <span>HTML</span> <span class="pull-right">85%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <span>CSS3</span> <span class="pull-right">85%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 85%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <span>PHP</span> <span class="pull-right">50%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <span>JAVASCRIPT</span> <span class="pull-right">55%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 55%" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="about-me pt-4 pt-md-0">
                  <div class="title-box-2">
                    <h5 class="title-left">
                      About me
                    </h5>
                  </div>
                  <p class="lead">
                    Halo, Perkenalkan namaku Daffa Alya Jalaludin Amin, Saya adalah seorang Mahasiswa di Universitas Amikom Yogyakarta.
                  </p>
                  <p class="lead">
                    Saya mengambil Jurusan Teknik Komputer, dan sekarang sudah sampai di semeter 7.
                  </p>
                  <p class="lead">
                    Be Yourself and Never Surrender.
                  </p><br/>
                  <p class="lead">
                    My Media Socials Below :
                  </p>
                  <div class="socials">
                    <ul>
                      <li><a href="https://www.instagram.com/_.daffa_aja/"><span class="ico-circle"><i class="ion-social-instagram"></i></span></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- End About Section -->

<?php 
require_once "footer.php";
?>